
# 패키지 로딩 ------------------------------------------------------------------

library(data.table)
library(dplyr)
library(tidygraph)
library(ggraph)
library(stringr)
library(readxl)
library(purrr)

# 데이터 로딩 ------------------------------------------------------------------


topic_df <- read_xlsx("data/이머징이슈데이터_쿼리조회_2022.xlsx") 
topic_df
topic_df %>% colnames
# [1] "분석기간"                        "토픽ID"                          "토픽키워드 (키워드: 토픽중요도)"
# [4] "토픽에 할당된 뉴스원문의 수"     "노벨토픽 여부"                   "웹화면 표시여부"   
colnames(topic_df) <- c("period", "id", "keyword",
                        "news_n", "novel_check", "web_check")
setDT(topic_df)
topic_df %>% nrow # 1152
topic_df$id %>% unique %>% length # 96
topic_df[novel_check=="Y"] # 51
topic_df[, .N, by = .(id)][order(-N)][1:5,]
topic_df[id==1]
topic_df[id==6]
# id의 동일성 유지? or 기간별로 부여
topic_df$period %>% unique

#  [1] "20210101-20220131" "20210201-20220228" "20210301-20220331" "20210401-20220430" "20210501-20220531"
#  [6] "20210601-20220630" "20210701-20220731" "20210801-20220831" "20210901-20220930" "20211001-20221031"
# [11] "20211101-20221130" "20211201-20221231"
  


# 목표 ----------------------------------------------------------------------

# 점검: 
# 현재 데이터에서 각 기간을 관통하는 토픽 고유 id 부재
# 기간별로 토픽 인덱싱 증가 (아래 통계)
# 일단 특정 기간에서 토픽 주요 키워드 간의 네트워크 형성을 1차 목표로 설정

# 프로세스
# 1) 키워드를 허물어 뜨리고 (novelty 체크 보존) 
# 2) 중요도 값을 정리하고
# 3) 토픽 현황을 파악 & 정리 (top 여부 결정)
# 4) 키워드 네트워크 형태로 데이터 정리
# 5) 키워드 네트워크 시각화


# 1) 키워드 정리 ------------------------------------------------------------------
x <- temp1
clean_json_type <- function(x) {
  temp_text <- str_replace_all(x, "(^\\{|\\}$)", "")
  # temp_text
  temp_split <- strsplit(temp_text, ", ") %>% unlist
  temp_split2 <- strsplit(temp_split, ": ")
  temp_keyword <- map(temp_split2, 1)
  temp_keyword <- map_chr(temp_keyword, function(x) {
                           str_remove_all(x, "^'|'$")})
  temp_value <- map(temp_split2, 2) %>% as.numeric
  temp_df <- data.table(keyword = temp_keyword,
                        imp_val = temp_value)
  return(temp_df)
}

setDT(topic_df)
topic_df_temp <- topic_df[period=="20211201-20221231"]
topic_df_temp # 96





topic_long <- topic_df[, clean_json_type(keyword), by = .(id, news_n, novel_check, period)]
topic_long[keyword=="에너지"]
topic_long$keyword %>% unique %>% length # 3480


# 기간별 토픽 현황 

# 토픽별 키워드 갯수 
topic_long[, .(N = .N), by = .(period, id)][, N] 

#                  period id  N
#    1: 20210101-20220131  1 30
#    2: 20210101-20220131  2 30
#    3: 20210101-20220131  3 30
#    4: 20210101-20220131  4 30
#    5: 20210101-20220131  5 30
#   ---                        
# 1148: 20211201-20221231 92 30
# 1149: 20211201-20221231 93 30
# 1150: 20211201-20221231 94 30
# 1151: 20211201-20221231 95 30
# 1152: 20211201-20221231 96 30
topic_long[, .(N = .N), by = .(period, id)][, N] %>% unique # 30

# 12개 기간별 토픽수
topic_long[, .(topic_unique_n = .SD$id %>% unique %>% length), by = .(period)][order(period)]

#                period topic_unique_n
#  1: 20210101-20220131             96
#  2: 20210201-20220228             96
#  3: 20210301-20220331             96
#  4: 20210401-20220430             96
#  5: 20210501-20220531             96
#  6: 20210601-20220630             96
#  7: 20210701-20220731             96
#  8: 20210801-20220831             96
#  9: 20210901-20220930             96
# 10: 20211001-20221031             96
# 11: 20211101-20221130             96
# 12: 20211201-20221231             96

# 96*12=1152 OK

# 기간별 토픽 평균 뉴스기사수
topic_long_compact <- topic_long[, .(period, id, news_n)] %>% unique
topic_long_compact
topic_avg_n_tbl <- topic_long_compact[, .(topic_n = .N,
                                          topic_avg_news_n = mean(news_n)), 
                            by = .(period)]
topic_avg_n_tbl
#                period topic_n topic_avg_news_n
#  1: 20210101-20220131      96         988.3229
#  2: 20210201-20220228      96        1006.5729
#  3: 20210301-20220331      96        1028.8750
#  4: 20210401-20220430      96        1025.5729
#  5: 20210501-20220531      96        1005.7188
#  6: 20210601-20220630      96        1015.8542
#  7: 20210701-20220731      96        1010.7812
#  8: 20210801-20220831      96         975.8125
#  9: 20210901-20220930      96        1015.8021
# 10: 20211001-20221031      96        1025.7604
# 11: 20211101-20221130      96        1029.0000
# 12: 20211201-20221231      96        1007.2708


# 토픽 확인 (상위 10개 바차트) -------------------------------------------------------------------

library(tidytext)
# 가장 최근 period에서 에너지가 키워드로 들어 있는 토픽
topic_long[period=="20211201-20221231" & keyword=="에너지"]

#    id news_n novel_check            period keyword     imp_val
# 1: 39    717           N 20211201-20221231  에너지 0.007923510
# 2: 50    729           N 20211201-20221231  에너지 0.006352268
# 3: 62    852           N 20211201-20221231  에너지 0.020776618
# 4: 66   1183           N 20211201-20221231  에너지 0.022246642
# 5: 78    767           N 20211201-20221231  에너지 0.009554416

topic_set <- topic_long[period == "20211201-20221231"  & keyword=="에너지"][order(-news_n)][, id]
topic_set
# "66" "62" "78" "50" "39"

# 각 토픽별로 상위 10개 가져오기 
topic_long_temp <- topic_long[id %in% topic_set & period == "20211201-20221231"]
topic_long_temp_top10  <- topic_long_temp[order(id, -imp_val)][, .SD[1:10], by = .(id)]
# 뉴스기사 건수 순으로 토픽 factor 레벨 조정
topic_long_temp_top10[, id := factor(id, levels = topic_set, 
                                     labels = paste0("Topic ", topic_set))]
topic_long_temp_top10

topic_long_temp_top10 %>% 
  ggplot(aes(imp_val, reorder_within(keyword, imp_val, id), fill = id)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~id, scales = "free_y") +
  scale_x_continuous(expand = c(0, 0)) +
  scale_y_reordered() +
  labs(x = expression(imp_val), y = NULL) 

?geom_text

# 토픽확인 (토픽별 워드클라우드) -------------------------------------------------------
library(wordcloud2)

# Topic 66

wordcloud2(data = topic_long[id==66 & period == "20211201-20221231" ,
                             .(keyword, imp_val*1000)])
  
wordcloud2(data = topic_long[id==62 & period == "20211201-20221231" ,
                             .(keyword, imp_val*1000)])


# 중요도 값 새로정리 --------------------------------------------------------------


pair_construct <- function(x) {
  x <- sort(unique(x)) # 정렬 
  if (length(x) ==1) return(
    data.table(V1 = x, V2 = x)) # 솔로 음반이면 본인 것만 pair list 생성   
  temp_mat <- combn(x, 2) # combn 은 조합하여 행렬로 반환
  temp_dt <- as.data.table(t(temp_mat))
  return(temp_dt)
}


topic_period_temp <- topic_long[period=="20211201-20221231"]
topic_period_temp_top10 <- topic_period_temp[order(id, -imp_val)][, .SD[1:10,],
                                                                  by = .(id)]

topic_period_long <- topic_period_temp_top10[, pair_construct(keyword),
                                       by = .(id)]
topic_period_long2 <- topic_period_long[, .(V1, V2, id)]
colnames(topic_period_long2) <- c("from", "to", "topic")
temp_g <- as_tbl_graph(topic_period_long2, directed = FALSE)
temp_g
ggraph(temp_g) +
  geom_edge_link() +
  geom_node_point() 
